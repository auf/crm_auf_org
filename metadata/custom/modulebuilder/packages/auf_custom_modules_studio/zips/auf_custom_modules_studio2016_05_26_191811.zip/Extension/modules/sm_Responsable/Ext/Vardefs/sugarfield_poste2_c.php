<?php
 // created: 2016-01-08 13:29:01
$dictionary['sm_Responsable']['fields']['poste2_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['poste2_c']['labelValue']='Poste 2';

 ?>