<?php
 // created: 2016-01-08 13:29:40
$dictionary['sm_Responsable']['fields']['phone_fax_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['phone_fax_c']['labelValue']='Télécopieur 1';

 ?>