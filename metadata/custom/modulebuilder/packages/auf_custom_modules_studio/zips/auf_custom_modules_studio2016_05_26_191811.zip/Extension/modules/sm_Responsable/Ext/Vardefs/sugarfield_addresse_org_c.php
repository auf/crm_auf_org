<?php
 // created: 2016-01-08 13:34:08
$dictionary['sm_Responsable']['fields']['addresse_org_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['addresse_org_c']['labelValue']='Utiliser l\'adresse de l\'organisme';

 ?>