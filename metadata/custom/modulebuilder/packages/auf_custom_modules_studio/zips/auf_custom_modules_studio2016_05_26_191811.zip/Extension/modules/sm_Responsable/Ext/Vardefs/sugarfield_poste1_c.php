<?php
 // created: 2016-01-08 13:25:26
$dictionary['sm_Responsable']['fields']['poste1_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['poste1_c']['labelValue']='Poste 1';

 ?>