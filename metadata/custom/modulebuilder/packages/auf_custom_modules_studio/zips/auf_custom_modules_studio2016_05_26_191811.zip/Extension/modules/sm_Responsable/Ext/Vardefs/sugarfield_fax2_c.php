<?php
 // created: 2016-01-08 13:33:18
$dictionary['sm_Responsable']['fields']['fax2_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['fax2_c']['labelValue']='Télécopieur 2';

 ?>