<?php
 // created: 2016-01-07 15:08:08
$dictionary['sm_Responsable']['fields']['modified_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['modified_c']['labelValue']='modified';

 ?>