<?php
 // created: 2016-01-08 13:25:59
$dictionary['sm_Responsable']['fields']['phone_alternate_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['phone_alternate_c']['labelValue']='Téléphone 2';

 ?>