<?php
 // created: 2016-01-08 13:20:33
$dictionary['sm_Responsable']['fields']['adresse_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['adresse_c']['labelValue']='Adresse';

 ?>