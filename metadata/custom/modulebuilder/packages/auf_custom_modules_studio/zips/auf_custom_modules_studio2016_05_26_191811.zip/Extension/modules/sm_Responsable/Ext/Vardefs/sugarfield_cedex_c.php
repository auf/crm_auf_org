<?php
 // created: 2016-01-08 13:22:09
$dictionary['sm_Responsable']['fields']['cedex_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['cedex_c']['labelValue']='Cedex';

 ?>