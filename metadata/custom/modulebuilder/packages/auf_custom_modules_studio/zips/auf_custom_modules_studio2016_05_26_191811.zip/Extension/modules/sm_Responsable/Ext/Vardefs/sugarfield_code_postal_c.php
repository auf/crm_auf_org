<?php
 // created: 2016-01-08 13:21:45
$dictionary['sm_Responsable']['fields']['code_postal_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['code_postal_c']['labelValue']='Code Postal';

 ?>