<?php
 // created: 2016-01-08 13:22:33
$dictionary['sm_Responsable']['fields']['province_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['province_c']['labelValue']='Province';

 ?>