<?php
 // created: 2016-03-04 16:44:58
$dictionary['sm_Responsable']['fields']['name']['inline_edit']=true;
$dictionary['sm_Responsable']['fields']['name']['duplicate_merge']='disabled';
$dictionary['sm_Responsable']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['sm_Responsable']['fields']['name']['merge_filter']='disabled';
$dictionary['sm_Responsable']['fields']['name']['unified_search']=false;

 ?>