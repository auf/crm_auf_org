<?php
 // created: 2016-01-08 13:28:27
$dictionary['sm_Responsable']['fields']['phone_office_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['phone_office_c']['labelValue']='Téléphone 1';

 ?>