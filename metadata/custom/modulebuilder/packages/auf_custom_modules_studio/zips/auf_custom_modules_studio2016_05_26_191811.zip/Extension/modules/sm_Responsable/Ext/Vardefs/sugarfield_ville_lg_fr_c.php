<?php
 // created: 2016-01-08 13:23:00
$dictionary['sm_Responsable']['fields']['ville_lg_fr_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['ville_lg_fr_c']['labelValue']='Ville (français)';

 ?>