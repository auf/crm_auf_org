<?php
 // created: 2015-12-21 13:34:14
$dictionary['sm_Responsable']['fields']['date_modified']['inline_edit']=true;
$dictionary['sm_Responsable']['fields']['date_modified']['comments']='Date record last modified';
$dictionary['sm_Responsable']['fields']['date_modified']['merge_filter']='disabled';

 ?>