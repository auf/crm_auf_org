<?php
 // created: 2016-01-11 14:15:47
$dictionary['sm_Responsable']['fields']['pays_iso2_c']['inline_edit']='1';
$dictionary['sm_Responsable']['fields']['pays_iso2_c']['labelValue']='Pays';

 ?>