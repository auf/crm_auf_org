<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class sm_ResponsableViewEdit extends ViewEdit
{
	function sm_ResponsableViewEdit(){
		parent::ViewEdit();
		$this->useForSubpanel = true;
 		$this->useModuleQuickCreateTemplate = true;

		}

function display()
 	{
        
  require_once("custom/include/metrix/loadDynamicLists.php"); //helper class to autopoluate the dropdowns
  require_once('include/utils.php');
  
  global  $current_user,$app_list_strings; 

/********************************************************************************************************/
/*                                                   dynamic dd                                         */
/********************************************************************************************************/ 
//TODO
  $dynamic_dd_fileds = array(
 	 //"priorite" =>array("tblname"=>"","listname"=>"priorite_list","field"=>""),
 	 "pays_iso2_c" =>array("tblname"=>"ref_pays","listname"=>"pays_iso2_c_list","field"=>"nom"),
 	
 	 
  );


  $list = new loadDynamicLists();
  foreach($dynamic_dd_fileds as $k=>$v){

		unset($app_list_strings[$v['listname']]);
		$app_list_strings[$v['listname']] = $list->populate_list($v['tblname'],$v['field']);
	
  }

  
	        

        


	 $this->ev->process();	
	 parent::display();
 	}
}