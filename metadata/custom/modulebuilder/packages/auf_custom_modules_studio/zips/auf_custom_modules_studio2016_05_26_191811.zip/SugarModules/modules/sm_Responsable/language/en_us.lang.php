<?php 
 // created: 2016-05-26 19:18:09
$mod_strings['LBL_FONCTION'] = 'Fonction DNU';
$mod_strings['LBL_NAME'] = 'Fonction';

?>
