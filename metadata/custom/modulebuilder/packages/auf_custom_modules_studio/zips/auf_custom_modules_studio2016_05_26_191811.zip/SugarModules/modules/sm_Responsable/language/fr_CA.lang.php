<?php 
 // created: 2016-05-26 19:18:09
$mod_strings['LBL_DATE_MODIFIED'] = 'Modifié le';
$mod_strings['LBL_NAME'] = 'Fonction';
$mod_strings['LBL_ID_ETABLISSEMENT'] = 'ID Etablissement';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Information responsable';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Information contact';
$mod_strings['LBL_MODIFIED'] = 'modified';
$mod_strings['LBL_ADRESSE'] = 'Adresse';
$mod_strings['LBL_CODE_POSTAL'] = 'Code Postal';
$mod_strings['LBL_CEDEX'] = 'Cedex';
$mod_strings['LBL_PROVINCE'] = 'Province';
$mod_strings['LBL_VILLE_LG_FR'] = 'Ville (français)';
$mod_strings['LBL_VILLE_LG_ORIGINE'] = 'Ville (langue d&#039;origine)';
$mod_strings['LBL_PAYS_ISO2'] = 'Pays';
$mod_strings['LBL_TEL1'] = 'Téléphone 1';
$mod_strings['LBL_POSTE1'] = 'Poste 1';
$mod_strings['LBL_PHONE_ALTERNATE'] = 'Téléphone 2';
$mod_strings['LBL_PHONE_OFFICE'] = 'Téléphone 1';
$mod_strings['LBL_POSTE2'] = 'Poste 2';
$mod_strings['LBL_PHONE_FAX'] = 'Télécopieur 1';
$mod_strings['LBL_FAX2'] = 'Télécopieur 2';
$mod_strings['LBL_ADDRESSE_ORG'] = 'Utiliser l&#039;adresse de l&#039;organisme';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Addresse';
$mod_strings['LBL_FONCTION'] = 'Fonction DNU';
$mod_strings['LBL_SM_RESPONSABLE_CONTACTS_1_FROM_CONTACTS_TITLE'] = 'Contact';
$mod_strings['LBL_PRIORITE'] = 'Priorité';
$mod_strings['LBL_CONTACTS_SM_RESPONSABLE_1_FROM_CONTACTS_TITLE'] = 'Contact';
$mod_strings['LBL_ACCOUNTS_SM_RESPONSABLE_1_FROM_ACCOUNTS_TITLE'] = 'Établissements';

?>
