<?php 
 // created: 2016-05-26 19:18:05
$mod_strings['LNK_NEW_RECORD'] = 'Créer Fournisseurs';
$mod_strings['LNK_LIST'] = 'Vue Fournisseurs';
$mod_strings['LNK_IMPORT_FS_FOURNISEUR'] = 'Import Fournisseurs';
$mod_strings['MSG_SHOW_DUPLICATES'] = 'Créer ce Compte peut potentiellement créer un Compte dupliqué. Vous pouvez cliquer sur Sauvegarder pour continuer de créer ce nouveau Compte  avec les données précédement saisies ou cliquer sur Annuler.';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Fournisseur Liste';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Recherche Fournisseur';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'Mes Fournisseurs';

?>
